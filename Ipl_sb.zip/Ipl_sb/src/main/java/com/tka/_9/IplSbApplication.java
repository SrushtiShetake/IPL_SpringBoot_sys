package com.tka._9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IplSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(IplSbApplication.class, args);
	}

}
